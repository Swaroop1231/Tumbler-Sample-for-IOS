//
//  TwitterConnector.m
//  Tumblr
//
//  Created by Kashif Jilani on 12/22/12.
//  Copyright (c) 2012 Kashif Jilani. All rights reserved.
//

#import "TwitterConnector.h"

@implementation TwitterConnector


- (void)start {
    consumer = [[OAConsumer alloc] initWithKey:kMyApplicationConsumerKey secret:kMyApplicationConsumerSecret];
    
    NSURL* requestTokenUrl = [NSURL URLWithString:@"http://www.tumblr.com/oauth/request_token"];
    OAMutableURLRequest* requestTokenRequest = [[[OAMutableURLRequest alloc] initWithURL:requestTokenUrl
                                                                                consumer:consumer
                                                                                   token:nil
                                                                                   realm:nil
                                                                       signatureProvider:nil] autorelease];
    OARequestParameter* callbackParam = [[[OARequestParameter alloc] initWithName:@"oauth_callback" value:@"tumblr://authorized"] autorelease];
    [requestTokenRequest setHTTPMethod:@"POST"];
    [requestTokenRequest setParameters:[NSArray arrayWithObject:callbackParam]];
    OADataFetcher* dataFetcher = [[[OADataFetcher alloc] init] autorelease];
    [dataFetcher fetchDataWithRequest:requestTokenRequest
                             delegate:self
                    didFinishSelector:@selector(didReceiveRequestToken:data:)
                      didFailSelector:@selector(didFailOAuth:error:)];
}

- (void)didReceiveRequestToken:(OAServiceTicket*)ticket data:(NSData*)data {
    NSString* httpBody = [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];
    requestToken = [[OAToken alloc] initWithHTTPResponseBody:httpBody];
    
    NSURL* authorizeUrl = [NSURL URLWithString:@"https://www.tumblr.com/oauth/authorize"];
    OAMutableURLRequest* authorizeRequest = [[[OAMutableURLRequest alloc] initWithURL:authorizeUrl
                                                                             consumer:nil
                                                                                token:nil
                                                                                realm:nil
                                                                    signatureProvider:nil] autorelease];
    NSString* oauthToken = requestToken.key;
    OARequestParameter* oauthTokenParam = [[[OARequestParameter alloc] initWithName:@"oauth_token" value:oauthToken] autorelease];
    [authorizeRequest setParameters:[NSArray arrayWithObject:oauthTokenParam]];
    
    UIWebView* webView = [[UIWebView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    [[[UIApplication sharedApplication] keyWindow] addSubview:webView];
    [webView release];
    
    webView.delegate = self;
    [webView loadRequest:authorizeRequest];
}

- (void)didReceiveAccessToken:(OAServiceTicket*)ticket data:(NSData*)data {
   
    NSString* httpBody = [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];
    accessToken = [[OAToken alloc] initWithHTTPResponseBody:httpBody];
    
    AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    delegate.OAuthKey = accessToken.key; // Here we will get the tumblr OAuth Key
    delegate.OAuthSecret = accessToken.secret;  // Here we will get the tumblr OAuth Secret Key
    // FINISHED!
}

- (void)didFailOAuth:(OAServiceTicket*)ticket error:(NSError*)error {
    // ERROR!
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark UIWebViewDelegate

- (BOOL)webView:(UIWebView*)webView shouldStartLoadWithRequest:(NSURLRequest*)request navigationType:(UIWebViewNavigationType)navigationType {
    if ([[[request URL] scheme] isEqualToString:@"tumblr"]) {
        
        // Extract oauth_verifier from URL query
        NSString* verifier = nil;
        NSArray* urlParams = [[[request URL] query] componentsSeparatedByString:@"&"];
        for (NSString* param in urlParams) {
            NSArray* keyValue = [param componentsSeparatedByString:@"="];
            NSString* key = [keyValue objectAtIndex:0];
            if ([key isEqualToString:@"oauth_verifier"]) {
                verifier = [keyValue objectAtIndex:1];
                break;
            }
        }
        
        if (verifier) {
            NSURL* accessTokenUrl = [NSURL URLWithString:@"https://www.tumblr.com/oauth/access_token"];
            OAMutableURLRequest* accessTokenRequest = [[[OAMutableURLRequest alloc] initWithURL:accessTokenUrl
                                                                                       consumer:consumer
                                                                                          token:requestToken
                                                                                          realm:nil
                                                                              signatureProvider:nil] autorelease];
            OARequestParameter* verifierParam = [[[OARequestParameter alloc] initWithName:@"oauth_verifier" value:verifier] autorelease];
            [accessTokenRequest setHTTPMethod:@"POST"];
            [accessTokenRequest setParameters:[NSArray arrayWithObject:verifierParam]];
            OADataFetcher* dataFetcher = [[[OADataFetcher alloc] init] autorelease];
            [dataFetcher fetchDataWithRequest:accessTokenRequest
                                     delegate:self
                            didFinishSelector:@selector(didReceiveAccessToken:data:)
                              didFailSelector:@selector(didFailOAuth:error:)];
        } else {
            // ERROR!
        }
        
        [webView removeFromSuperview];
        
        return NO;
    }
    return YES;
}

- (void)webView:(UIWebView*)webView didFailLoadWithError:(NSError*)error {
    // ERROR!
}
@end
