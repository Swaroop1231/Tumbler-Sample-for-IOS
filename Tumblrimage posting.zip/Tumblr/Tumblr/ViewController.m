//
//  ViewController.m
//  Tumblr
//
//  Created by Kashif Jilani on 12/22/12.
//  Copyright (c) 2012 Kashif Jilani. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    TwitterConnector *tweetConnect = [[TwitterConnector alloc] init];
    [tweetConnect start];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)tumblrClicked:(id)sender {
    
    AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    NSData *data1 = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"picture1" ofType:@"jpg"]];
    
   // NSData *data2 = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"picture2" ofType:@"jpg"]];
    NSArray *array = [NSArray arrayWithObject:data1];
    dispatch_async( dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        TumblrUploadr *tu = [[TumblrUploadr alloc] initWithNSDataForPhotos:array andBlogName:@"vasuippili.tumblr.com" andDelegate:self andCaption:@"Great Photos!"];
        dispatch_async( dispatch_get_main_queue(), ^{
            [tu signAndSendWithTokenKey:delegate.OAuthKey andSecret:delegate.OAuthSecret];
        });
    });
}

- (void) tumblrUploadr:(TumblrUploadr *)tu didFailWithError:(NSError *)error {
    NSLog(@"connection failed with error %@",[error localizedDescription]);
    [tu release];
}
- (void) tumblrUploadrDidSucceed:(TumblrUploadr *)tu withResponse:(NSString *)response {
    NSLog(@"connection succeeded with response: %@", response);
    [tu release];
}

@end
