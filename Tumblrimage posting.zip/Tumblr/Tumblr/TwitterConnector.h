//
//  TwitterConnector.h
//  Tumblr
//
//  Created by Kashif Jilani on 12/22/12.
//  Copyright (c) 2012 Kashif Jilani. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "OAConsumer.h"
#import "OAToken.h"
#import "OAMutableURLRequest.h"
#import "OADataFetcher.h"
#import "AppDelegate.h"

static NSString* kMyApplicationConsumerKey = @"tJExeoLiY27RnqI5CCTaW4AYuHod8Ok9TlX1okK3KKMG0WHrIZ"; // Enter your tumblr Consumer key
static NSString* kMyApplicationConsumerSecret = @"u2sVPGig7rOm6bxcm9peGsJOYEjTzjAokzseApTx7twc84LFzn";    // Enter your tumblr Consumer secret key

@interface TwitterConnector : NSObject <UIWebViewDelegate> {
    
    OAConsumer* consumer;
    OAToken* requestToken;
    OAToken* accessToken;
}

-(void)start;

@end
