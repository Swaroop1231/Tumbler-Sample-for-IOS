//
//  ViewController.h
//  Tumblr
//
//  Created by Kashif Jilani on 12/22/12.
//  Copyright (c) 2012 Kashif Jilani. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TwitterConnector.h"
#import "TumblrUploadr.h"
#import "AppDelegate.h"

@interface ViewController : UIViewController <TumblrUploadrDelegate>

-(IBAction)tumblrClicked:(id)sender;

@end
