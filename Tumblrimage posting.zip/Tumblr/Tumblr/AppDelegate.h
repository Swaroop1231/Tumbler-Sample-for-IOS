//
//  AppDelegate.h
//  Tumblr
//
//  Created by Kashif Jilani on 12/22/12.
//  Copyright (c) 2012 Kashif Jilani. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate,UINavigationControllerDelegate> {
    
    UINavigationController *navigationController;
    
    NSString *OAuthKey;
    NSString *OAuthSecret;
}

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) ViewController *viewController;

@property (nonatomic, retain) UINavigationController *navigationController;

@property (nonatomic, retain) NSString *OAuthKey;
@property (nonatomic, retain) NSString *OAuthSecret;

@end
